"""
kimlik_dogrulama.py
--------------------
OpenSky kullanıcı adı/şifresini kod içine YAZMAK YERİNE ortam değişkenlerinden
(.env dosyası) okur. Eski `trino_baglanti.py` dosyanda şifre düz metin olarak
koda gömülüydü — bu, dosya yanlışlıkla paylaşılırsa veya bir git deposuna
gönderilirse şifrenin sızmasına yol açar. Bu modül o sorunu çözer.

Kullanım:
  1. Proje kök dizininde bir `.env` dosyası oluştur (bkz. `.env.example`):
       OPENSKY_KULLANICI=kullanici_adin
       OPENSKY_SIFRE=sifren
  2. `.env` dosyasını `.gitignore`'a ekle (zaten eklendi, bkz. .gitignore).
  3. Kodun geri kalanında `kimlik_bilgilerini_al()` fonksiyonunu kullan.
"""

import os
from dotenv import load_dotenv

load_dotenv()


class KimlikBilgisiEksikHatasi(Exception):
    """OPENSKY_KULLANICI / OPENSKY_SIFRE ortam değişkenleri tanımlı değilse fırlatılır."""
    pass


def kimlik_bilgilerini_al():
    """
    Ortam değişkenlerinden OpenSky kullanıcı adı ve şifresini döndürür.
    Bulunamazsa açıklayıcı bir hata fırlatır (sessizce None dönmez).
    """
    kullanici = os.getenv("OPENSKY_KULLANICI")
    sifre = os.getenv("OPENSKY_SIFRE")

    if not kullanici or not sifre:
        raise KimlikBilgisiEksikHatasi(
            "OPENSKY_KULLANICI ve/veya OPENSKY_SIFRE ortam değişkenleri bulunamadı.\n"
            "Proje kök dizininde bir '.env' dosyası oluşturup şu satırları ekle:\n"
            "  OPENSKY_KULLANICI=kullanici_adin\n"
            "  OPENSKY_SIFRE=sifren\n"
            "(Örnek için .env.example dosyasına bak.)"
        )

    return kullanici, sifre
