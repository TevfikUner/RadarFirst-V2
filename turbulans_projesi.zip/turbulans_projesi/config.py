"""
config.py
---------
Proje genelinde kullanılan sabitler ve ayarlar burada toplanır.
Böylece bir parametreyi değiştirmek için tek dosyayı güncellemek yeterli olur.
"""

# --- İlgilenilen coğrafi bölge (Türkiye ve yakın çevresi) ---
ENLEM_MIN, ENLEM_MAX = 36.0, 42.0
BOYLAM_MIN, BOYLAM_MAX = 26.0, 45.0

# --- OpenSky / Trino bağlantı ayarları ---
# NOT: Kullanıcı adı ve şifre ARTIK BURADA DEĞİL.
# Bunlar .env dosyasından okunuyor (bkz. kimlik_dogrulama.py).
TRINO_HOST = "trino.opensky-network.org"
TRINO_PORT = 443

# --- Copernicus / ERA5 veri küpü ---
HAVA_DURUMU_DOSYASI = "ocak_2019_turbulans.nc"

# Veri kübünde muhtemel değişken/boyut isimleri (dosyana göre kontrol et)
ZAMAN_BOYUTU = "valid_time"
BASINC_BOYUTU = "pressure_level"
ENLEM_BOYUTU = "latitude"
BOYLAM_BOYUTU = "longitude"

# --- Türbülans şiddeti sınıflandırma eşikleri ---
# Ellrod TI1 indeksinin kendi biriminde (s^-2), literatürde (Ellrod & Knapp,
# 1992) kullanılan yaklaşık eşik değerleri:
TI1_ESIK_HAFIF = 4e-7          # bu değerin altı: yeşil (sakin/hafif altı)
TI1_ESIK_ORTA_SIDDETLI = 8e-7  # bu değerin altı: turuncu (hafif-orta), üstü: kırmızı (orta-şiddetli)

# tanh ile 0-1 aralığına sıkıştırılmış "edr_proxy" değeri sadece popup'ta
# okunabilir bir sayı göstermek içindir; RENKLENDİRME artık ham TI1 üzerinden
# yapılıyor (bkz. harita.py).
EDR_PROXY_OLCEKLENDIRME_KATSAYISI = 1.5

# --- Sorgu limitleri (OpenSky'ı yormamak / ban yememek için) ---
MAKS_STATE_VECTOR_SATIRI = 5000
