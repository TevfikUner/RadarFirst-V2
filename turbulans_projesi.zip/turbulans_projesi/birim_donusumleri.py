"""
birim_donusumleri.py
---------------------
OpenSky uçuş verisi irtifayı METRE cinsinden verir (geoaltitude / baroaltitude),
Copernicus/ERA5 veri küpü ise seviyeleri BASINÇ (hPa) cinsinden tutar.
İki veri kaynağını eşleştirebilmek için bu iki birim arasında dönüşüm gerekir.
"""

import numpy as np

DENIZ_SEVIYESI_BASINCI_HPA = 1013.25  # ISA standart deniz seviyesi basıncı


def irtifa_metre_to_basinc_hpa(irtifa_metre):
    """
    Uluslararası Standart Atmosfer (ISA) barometrik formülüyle, metre cinsinden
    irtifayı yaklaşık basınç seviyesine (hPa) çevirir. 0-11 km (troposfer) için
    geçerlidir; uçuş irtifaları (~9-12 km) bu aralığa büyük ölçüde girer.
    """
    irtifa_metre = np.asarray(irtifa_metre, dtype=float)
    return DENIZ_SEVIYESI_BASINCI_HPA * (1 - (0.0065 * irtifa_metre) / 288.15) ** 5.255


def basinc_hpa_to_irtifa_metre(basinc_hpa):
    """Ters dönüşüm: basınç (hPa) -> yaklaşık irtifa (metre)."""
    basinc_hpa = np.asarray(basinc_hpa, dtype=float)
    oran = basinc_hpa / DENIZ_SEVIYESI_BASINCI_HPA
    return (288.15 / 0.0065) * (1 - oran ** (1 / 5.255))


def en_yakin_basinc_seviyesi(basinc_hpa, mevcut_seviyeler):
    """
    Hesaplanan basınç değerine, veri kübünde GERÇEKTEN bulunan seviyeler
    arasından en yakın olanını seçer (ör. 247 hPa hesaplandıysa ama küpte
    sadece [200, 250, 300, ...] varsa 250'yi döndürür).
    """
    mevcut_seviyeler = np.asarray(mevcut_seviyeler, dtype=float)
    indeks = int(np.argmin(np.abs(mevcut_seviyeler - basinc_hpa)))
    return float(mevcut_seviyeler[indeks])
